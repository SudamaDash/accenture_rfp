export const sections = [
    { label: "Client Name", placeholder: "Enter Client Name" },
    { label: "Opportunity ID", placeholder: "Enter Opportunity ID" },
    { label: "Opportunity Name", placeholder: "Enter Opportunity Name" },
  ];

 export const sections2 = [
    { label: "Framework", placeholder: "eg-Agile, etc." },
    { label: "WBSE", placeholder: "" },
    { label: "Solution Architect", placeholder: "" },
  ];
 export const sections3 = [
    { label: "Framework", placeholder: "eg-Agile, etc." },
    { label: "WBSE", placeholder: "" },
    { label: "Solution Architect", placeholder: "" },
  ];
 export const sec2 = [
    { label: "Framework", placeholder: "eg-Agile, etc." },
    { label: "WBSE", placeholder: "" },
    { label: "Solution Architect", placeholder: "" },
  ];
 export const sec3 = [
    { label: "Framework", placeholder: "eg-Agile, etc." },
    { label: "WBSE", placeholder: "" },
    { label: "Solution Architect", placeholder: "" },
  ];
 export const sec4 = [
    { label: "Framework", placeholder: "eg-Agile, etc." },
    { label: "WBSE", placeholder: "" },
    { label: "Solution Architect", placeholder: "" },
  ];