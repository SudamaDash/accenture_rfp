import React from "react";
import Home from "./main/home";
import Header from "./common/header/header";
import PdfToHtmlConverter from "./temp";

const App = () => {
  return (
    <>
     {/* <PdfToHtmlConverter/> */}
      <Home />
      
    </>
  );
};

export default App;
