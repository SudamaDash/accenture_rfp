import React from 'react'

const Progress = () => {
  return (
    <div>
      Hiiiii
    </div>
  )
}

export default Progress
